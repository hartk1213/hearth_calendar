# Running Hearth on Unraid (Docker + MariaDB)

You only edit one thing, and only once: the database login in `docker-compose.yml`. Everything else is set up on screen in the app: the family members, chore chart, linked calendars, weather and display. All of it is saved in MariaDB.

```
[Pi + 27" touch screen] --browser--> [Unraid: hearth container :8095] --> [Unraid: MariaDB :3306]
[phones on Wi-Fi] -------browser--/
```

## 1. Copy the files to the server (Windows)

1. Unzip `hearth.zip`: right-click it and choose **Extract All**.
2. Press **Win + R**, type `\\TOWER\appdata` (or `\\<unraid-ip>\appdata`) and press Enter.
   If it doesn't open, go to **Shares → appdata** in the Unraid web page, set **SMB Export** to **Yes**, and try again.
3. Copy the `hearth` folder in, so that you end up with `appdata\hearth\server.py`.

## 2. Fill in the database login

Open `appdata\hearth\docker-compose.yml` in Notepad and change these lines:

| Setting | Change it to |
|---|---|
| `DB_HOST` | Your Unraid server's IP address |
| `DB_PASSWORD` | A new password you make up for Hearth |
| `DB_ROOT_PASSWORD` | Your MariaDB root password, needed for the first start only |
| `TZ` | Your time zone, if it isn't `America/Los_Angeles` |
| `8095` | Leave it, unless another app already uses port 8095 |

## 3. Start it

1. In the Unraid web page, go to **Apps**, search for **Docker Compose Manager** and install it.
2. Click the **>_** terminal icon at the top right and paste:

```bash
chown -R nobody:users /mnt/user/appdata/hearth
cd /mnt/user/appdata/hearth
docker compose up -d --build
docker logs hearth
```

The first build takes a minute or two. The log should show `created database 'hearth'` and `Hearth is running`.

3. Delete the `DB_ROOT_PASSWORD` line from `docker-compose.yml`, then run `docker compose up -d` again. After this, Hearth no longer has your root password.

The container appears in the Docker tab with a WebUI link and starts automatically whenever the server boots.

## 4. Set it up in the app

Open **`http://<unraid-ip>:8095`** on your phone or computer. A short setup screen walks you through it:

1. Give your calendar a name.
2. Add each person, with a name and color. These people also become the columns on the chore chart.
3. Link calendars (optional). Paste a link from Google, iPhone or Outlook. The app checks the link and explains what went wrong if it doesn't work. Tap **"Where do I find the link?"** for step-by-step help.
4. Search for your town to get the weather (optional).

Anything can be changed later under **⚙ Settings**, including text size (choose **Large** for a 27" screen), night mode and a **PIN** that stops kids from changing settings.

It's easiest to paste calendar links from a phone or computer rather than typing on the wall screen. Changes made there show up on the wall within about 20 seconds.

## 5. Set up the Pi

On the Pi you only need a browser. Flash **Raspberry Pi OS (64-bit, with desktop)**, then open a terminal and run the following, using your Unraid IP in place of `192.168.1.10`:

```bash
cat > ~/hearth-kiosk.sh <<'EOF'
#!/bin/sh
# Wait for the Unraid server (useful after a power cut, when the Pi boots faster than Unraid)
until curl -sf http://192.168.1.10:8095/api/health >/dev/null; do sleep 5; done
exec chromium --kiosk --noerrdialogs --disable-infobars \
  --check-for-update-interval=31536000 "http://192.168.1.10:8095/?kiosk=1"
EOF
chmod +x ~/hearth-kiosk.sh
mkdir -p ~/.config/labwc && echo '~/hearth-kiosk.sh &' >> ~/.config/labwc/autostart
```

The `?kiosk=1` at the end tells Hearth it is on the wall screen, so it doesn't open recipe websites there (with no back button on a kiosk screen, you could get stuck). Then reboot the Pi. On older Pi OS images the browser command may be `chromium-browser`. Also turn off screen blanking under **Raspberry Pi menu → Preferences → Control Centre → Display**.

## Updating Hearth later

Replace `server.py` and the `static` folder in `appdata\hearth`, then run this in the Unraid terminal:

```bash
cd /mnt/user/appdata/hearth && docker compose up -d --build
```

Everything you set up lives in MariaDB, so updates don't touch it.

## Backups

All of Hearth's data is in the `hearth` database (table `hearth_state`), so your normal MariaDB backups cover it. For a quick manual copy:

```bash
docker exec <mariadb-container> mariadb-dump -u root -p hearth > /mnt/user/backups/hearth.sql
```

## Troubleshooting

- **Logs show `waiting for database...`:** check that `DB_HOST` is the server's IP (not `localhost`) and that your MariaDB container publishes port 3306.
- **Logs say the admin login failed:** some MariaDB containers only allow root from inside their own container. Create the database by hand instead: open your MariaDB container's **Console** in the Docker tab, run `mariadb -u root -p`, then paste the following, using the same password as `DB_PASSWORD`:
  ```sql
  CREATE DATABASE hearth CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
  CREATE USER 'hearth'@'%' IDENTIFIED BY 'same-as-DB_PASSWORD';
  GRANT ALL PRIVILEGES ON hearth.* TO 'hearth'@'%';
  FLUSH PRIVILEGES;
  ```
- **Calendar times are off by hours:** set `TZ` in `docker-compose.yml`, then run `docker compose up -d` again.
- **Forgot the PIN:** in the Unraid terminal, run `docker exec -it <mariadb-container> mariadb -u root -p hearth`, then
  `UPDATE hearth_state SET data = JSON_SET(data, '$.pin_hash', '') WHERE id = 2;` and then `docker restart hearth`.
