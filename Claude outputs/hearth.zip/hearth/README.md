# Hearth: a DIY family wall calendar

A touchscreen family hub you build yourself, with no subscription:

- **Calendar:** week, month and agenda views, with a color for each person.
- **Linked calendars:** Google, iPhone/iCloud and Outlook calendars, updated every few minutes.
- **Events:** add them right on the screen or from your phone.
- **Chore chart:** a column per person, chores that repeat on chosen days, and check-offs that reset daily.
- **Lists:** groceries, to-dos, and any other lists you create.
- **Meal planner:** tonight's dinner shows on the calendar.
- **Pantry and recipes (optional):** list the food you have. Then either find real recipes that use it, with photos and full steps, from the Spoonacular recipe database (free key), or ask Claude for ideas (Claude API key). Missing ingredients go to the grocery list and a meal goes on the plan in one tap. Turn these on under Settings; the keys stay on the server.
- **Weather, clock and night mode:** the screen goes dark overnight and wakes when tapped.
- **Phone access:** works from any phone on your home Wi-Fi.

**Everything is set up inside the app.** A setup screen runs the first time you open it, and later changes are made under ⚙ Settings. There are no config files to edit.

## How to install

- **Unraid server with MariaDB (recommended):** follow **[UNRAID.md](UNRAID.md)**. The server runs in Docker, data is stored in MariaDB, and the Pi only shows the screen.
- **Everything on one Raspberry Pi:** see "Standalone" below.

## Hardware

| Part | Notes |
|---|---|
| Raspberry Pi 5 (2 GB) | It only runs a web browser, so 2 GB is plenty. |
| Touch monitor (15.6" or 27") | It must send touch over **USB**. Prefer projected-capacitive (PCAP) touch and VESA 100×100 mounting holes. |
| Official Pi power supply + 32 GB microSD | |
| Micro-HDMI → HDMI cable (right-angle) + USB cable for touch | |
| VESA wall mount | Screw it into studs for a 27" screen. |

## Standalone (no server)

On a Pi running Raspberry Pi OS (64-bit, with desktop):

```bash
cd ~/hearth
python3 -m venv .venv
.venv/bin/pip install -r requirements.txt
.venv/bin/python server.py
```

Open `http://localhost:8080` and follow the setup screens. Data is saved in `data.json` and `settings.json` next to `server.py`, so back those up.

To start the server on boot, create `/etc/systemd/system/hearth.service`, replacing `pi` with your username:

```ini
[Unit]
Description=Hearth family calendar
After=network-online.target
Wants=network-online.target

[Service]
User=pi
WorkingDirectory=/home/pi/hearth
ExecStart=/home/pi/hearth/.venv/bin/python server.py
Restart=always

[Install]
WantedBy=multi-user.target
```

```bash
sudo systemctl enable --now hearth
```

For the full-screen browser, use the kiosk script in UNRAID.md step 5 with `http://localhost:8080` as the address.

## How it works

```
server.py   - small Python web server
  ├─ /api/config, /api/settings, /api/calendars   family, linked calendars, display settings
  ├─ /api/events   downloads linked calendars, expands repeating events, converts time zones
  ├─ /api/state    chores, lists, meals and events added in the app
  └─ /             static/index.html (the whole touchscreen app, one file)
```

- **Storage:** MariaDB/MySQL when `DB_HOST` is set, otherwise JSON files.
- **Calendar links stay private:** they're stored on the server only, and the app shows just a short hint of each one.
- **Simultaneous edits:** if two screens save at the same moment, the second change is applied on top of the first, so nothing is lost.
- **Server outages:** if the server or database goes down, the screen keeps showing its last copy and reconnects by itself.
- **Demo mode:** opening `static/index.html` directly, with no server, shows a sample family.

## Limitations

- **Linked calendars are read-only.** Events added in Hearth stay in Hearth and aren't sent back to Google, iCloud or Outlook.
- **No login.** Anyone on your home Wi-Fi can open the app. The optional PIN only protects Settings. Don't expose the port to the internet.
- **Night mode doesn't turn off the backlight.** It only shows a black screen.
